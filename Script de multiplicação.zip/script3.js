    var y = prompt("Digite um número?");   
    y = parseInt(y); /* converter*/ 
    x = y*2;              
    alert("A multiplicação será " + x );  /* multiplicação ok*/